g++ main.cpp -o main -std=c++11 -Wall -Wshadow -Wpedantic -Wextra -O0
